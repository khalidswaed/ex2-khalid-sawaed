/******************
Name: khalid swaed
ID: 326332525
Assignment: ex2
*******************/

#include <stdio.h>



int main()
{
	int option;
	{
		printf("choose an option:\n");
		printf("1. Happy Face\n");
		printf("2. Balanced Number\n");
		printf("3. Generous Number\n");
		printf("4. Circle Of Joy\n");
		printf("5. Happy Numbers\n");
		printf("6. Festival Of Laughter\n");
		printf("7. Exit\n");
		scanf("%d", &option);
		while (option < 1 || option > 7){printf("This option is not available, please try again.\n");
			scanf("%d", &option);
			break;;}

		switch (option)
		{
			// Case 1: Draw Happy Face with given symbols for eyes, nose and mouse
			/* Example:
			* n = 3:
			* 0   0
			*   o
			* \___/
			*/
		case 1:
			{
				if (option == 1)
				{


					{
						int size;
						char eyes, nose, mouth;
						 {
							// Asking user for the symbols to use for eyes, nose, and mouth
							printf("Choose symbols for eyes, nose, and mouth: ");
							// Get the symbols. We need to handle spaces correctly for the format
							scanf(" %c %c %c", &eyes, &nose, &mouth);

							// Asking user for face size
							printf("Choose a face size (it must be an odd and positive number): ");
							// Ensure the size is a positive odd number
							while (size <= 0 || size % 2 == 0) {
								printf("The face size must be an odd and positive number. Please try again: ");
								scanf("%d", &size);
							}
							// Draw the happy face
							printf("%c ", eyes); // Print the eyes at the top left
							for (int i = 0; i < size; i++) {
								printf(" "); // Print spaces between eyes
							}
							printf("%c\n", eyes); // Print the eyes at the top right
							// Print the upper part of the face with nose
							for (int i = 0; i < size / 2; i++) {
								printf(" "); // Add spaces before the nose
							}
							printf("%c\n", nose); // Print the nose

							// Print the mouth (in the shape of a curved line)
							printf("\\");
							for (int i = 0; i < size; i++) {
								printf("%c", mouth); // Print the mouth
							}
							printf("/\n"); // Close the mouth
						}
					}
				}
			}

					case 2:
						{
							// Case 2: determine whether the sum of all digits to the left of the middle digit(s)
							// and the sum of all digits to the right of the middle digit(s) are equal
							/* Examples:
							Balanced: 1533, 450810, 99
							Not blanced: 1552, 34
							Please notice: the number has to be bigger than 0.
							*/
							if (option == 2) {
								int number2, leftSum = 0, rightSum = 0;
								printf("Enter a positive number: ");
								scanf("%d", &number2);
								while (number2 <= 0) {
									printf("Only positive numbers are allowed, try again: ");
									scanf("%d", &number2);
								}
								// Calculate sum of digits on the left and right
								int numCopy = number2, digits = 0;
								while (numCopy > 0) {
									digits++;
									numCopy /= 10;
								}
								numCopy = number2;
								int mid = digits / 2;
								for (int i = 0; i < mid; i++) {
									rightSum += numCopy % 10;
									numCopy /= 10;
								}
								if (digits % 2 == 1) {
									numCopy /= 10; // Skip the middle digit if odd number of digits
								}
								for (int i = mid; i < digits; i++) {
									leftSum += numCopy % 10;
									numCopy /= 10;
								}
								if (leftSum == rightSum) {
									printf("The number is balanced!\n");
								} else {
									printf("The number is not balanced.\n");
								}
							}
						}
					case 3:
						{
							// Case 3: determine whether the sum of the proper divisors (od an integer) is greater than the number itself
							/* Examples:
							Abudant: 12, 20, 24
							Not Abudant: 3, 7, 10
							Please notice: the number has to be bigger than 0.
							*/
							if (option == 3); {
								int number3, sum_of_divisors = 0;
								// Get user input for a positive number
								printf("Enter a positive number: ");
								scanf("%d", &number3);
								// Validate input (number must be positive)
								while (number3 <= 0) {
									printf("Only positive number is allowed, please try again: ");
									scanf("%d", &number3);
								}
								// Calculate sum of proper divisors
								for (int i = 1; i <= number3 / 2; i++) {
									if (number3 % i == 0) {  // If i is a divisor of number
										sum_of_divisors += i; // Add it to the sum
									}
								}
								// Check if the number is generous (sum of divisors > number)
								if (sum_of_divisors > number3) {
									printf("This number is generous!\n");
								} else {
									printf("This number is not generous.\n");
								}
							}
						}
					case 4:
						{	// Case 4: determine wether a number is a prime.
							/* Examples:
							This one brings joy: 3, 5, 11
							This one does not bring joy: 15, 8, 99
							Please notice: the number has to be bigger than 0.
							*/
							if(option==4);
							{
								{
									int number, i, is_prime = 1;
									// ask for number and check if its positive
									do {
										printf("Enter a positive number: ");
										scanf("%d", &number);
										if (number <= 0) {
											printf("Only positive numbers are allowed, please try again:\n");
										}
									} while (number <= 0);
									// Check if the number is prime
									if (number == 1) {
										is_prime = 0; // 1 is not a prime number
									} else {
										for (i = 2; i <= number / 2; i++) {
											if (number % i == 0) {
												is_prime = 0; // Number is divisible by i
												break;
											}
										}
									}
									// Print the result
									if (is_prime) {
										printf(" %d This number completes the circle of joy!\n", number);
									} else {
										printf(" The circle remains incomplete..\n");
									}
								}
							}
						}
					case 5:
						{

							{
								// Happy numbers: Print all the happy numbers between 1 to the given number.
								// Happy number is a number which eventually reaches 1 when replaced by the sum of the square of each digit
								/* Examples:
								Happy :) : 7, 10
								Not Happy :( : 5, 9
								Please notice: the number has to be bigger than 0.
								*/if(option==5);
								{


									int main(); {
										int n, i, num, slow, fast, digit, sum;

										// Ask the user to enter a positive number n
										printf("Enter a positive number: ");
										while (1) {
											if (scanf("%d", &n) != 1 || n <= 0) {
												printf("Only positive number is allowed, please try again:\n");
												while (getchar() != '\n');  // Clear the input buffer
												continue;
											}
											break;
										}

										// Print all happy numbers between 1 and n
										printf("Happy numbers between 1 and %d: ", n);

										// Loop through all numbers from 1 to n
										for (i = 1; i <= n; i++) {
											num = i;
											slow = num;
											fast = num;
											// Check if the number is happy using slow and fast pointers
											while (fast != 1 && slow != fast) {
												// Calculate sum of squares of digits for slow pointer
												sum = 0;
												while (slow > 0) {
													digit = slow % 10;  // Get the last digit
													sum += digit * digit;  // Add square of the digit to sum
													slow /= 10;  // Remove the last digit
												}
												slow = sum;  // Update slow pointer

												// Calculate sum of squares of digits for fast pointer (twice)
												sum = 0;
												while (fast > 0) {
													digit = fast % 10;  // Get the last digit
													sum += digit * digit;  // Add square of the digit to sum
													fast /= 10;  // Remove the last digit
												}
												fast = sum;  // Update fast pointer
												sum = 0;
												while (fast > 0) {
													digit = fast % 10;
													sum += digit * digit;
													fast /= 10;
												}
												fast = sum;
											}

											// If fast pointer reaches 1, then it's a happy number
											if (fast == 1) {
												printf("%d ", i);  // Print the happy number
											}
										}
										printf("\n");


										int main() ;{
											int n, i, num, slow, fast, digit, sum;

											// Ask the user to enter a positive number n
											printf("Enter a positive number: ");
											while (1) {
												if (scanf("%d", &n) != 1 || n <= 0) {
													printf("Only positive number is allowed, please try again:\n");
													while (getchar() != '\n');  // Clear the input buffer
													continue;
												}
												break;
											}

											// Print all happy numbers between 1 and n
											printf("Happy numbers between 1 and %d: ", n);

											// Loop through all numbers from 1 to n
											for (i = 1; i <= n; i++) {
												num = i;
												slow = num;
												fast = num;
												// Check if the number is happy using slow and fast pointers
												while (fast != 1 && slow != fast) {
													// Calculate sum of squares of digits for slow pointer
													sum = 0;
													while (slow > 0) {
														digit = slow % 10;  // Get the last digit
														sum += digit * digit;  // Add square of the digit to sum
														slow /= 10;  // Remove the last digit
													}
													slow = sum;  // Update slow pointer

													// Calculate sum of squares of digits for fast pointer (twice)
													sum = 0;
													while (fast > 0) {
														digit = fast % 10;  // Get the last digit
														sum += digit * digit;  // Add square of the digit to sum
														fast /= 10;  // Remove the last digit
													}
													fast = sum;  // Update fast pointer
													sum = 0;
													while (fast > 0) {
														digit = fast % 10;
														sum += digit * digit;
														fast /= 10;
													}
													fast = sum;
												}
												// If fast pointer reaches 1, then it's a happy number
												if (fast == 1) {
													printf("%d ", i);  // Print the happy number
												}
											}
											printf("\n");
										}
									}
								}

								case 6:{// Festival of Laughter: Prints all the numbers between 1 the given number:
										// and replace with "Smile!" every number that divided by the given smile number
										// and replace with "Cheer!" every number that divided by the given cheer number
										// // and replace with "Festival!" every number that divided by both of them
										/* Example:
										6, smile: 2, cheer: 3 : 1, Smile!, Cheer!, Smile!, 5, Festival!
										*/
										if(option==6){
											{
												int smileNumber, cheerNumber, n;
												int validInput = 0;
												// Input validation for smile and cheer numbers
												while (!validInput) {
													printf("Enter smile and cheer numbers':\n");
													if (scanf("smile:%d, cheer:%d", &smileNumber, &cheerNumber) == 2 &&
													smileNumber > 0 && cheerNumber > 0 && smileNumber != cheerNumber) {
														validInput = 1;  // Valid input
													} else {
														printf("Only 2 different positive numbers in the given format are allowed for the festival, please try again:\n");
														while (getchar() != '\n');  // Clear input buffer
													}
												}
												// Input validation for positive maximum number
												validInput = 0;
												while (!validInput) {
													printf("Enter a positive maximum number: ");
													if (scanf("%d", &n) == 1 && n > 0) {
														validInput = 1;  // Valid input
													} else {
														printf("Only positive maximum number is allowed, please try again:\n");
														while (getchar() != '\n');  // Clear input buffer
													}
												}
												// Print numbers with replacements
												for (int i = 1; i <= n; i++) {
													if (i % smileNumber == 0 && i % cheerNumber == 0) {
														printf("Festival! ");
													} else if (i % smileNumber == 0) {
														printf("Smile! ");
													} else if (i % cheerNumber == 0) {
														printf("Cheer! ");
													} else {
														printf("%d ", i);
													}
												}
												printf("\n");
											}
										}
										case 7:{	if (option == 7) { printf("Thank you for your journey through Numeria!\n") ;}
										}
								}

							}
						}
				}
			}
			}
